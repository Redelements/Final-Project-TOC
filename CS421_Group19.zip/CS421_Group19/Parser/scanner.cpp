#include<iostream>
#include<fstream>
#include<string>
using namespace std;

/* Look for all **'s and complete them */

//=====================================================
// File scanner.cpp written by: Group Number: ** 19
//=====================================================

// --------- Two DFAs ---------------------------------

// WORD DFA
// Done by: **Joel Antony
// RE:   **(vowel | vowel n | consonant vowel | consonant vowel n |
//        consonant-pair vowel | consonant-pair vowel n)^+
  
bool word(string s)
{
  string state ="Q0";
  int charpos = 0;

  while (s[charpos] != '\0')
    {
      
      

// q0                                                                                                                                                                                            
      if (state == "Q0" && (s[charpos] == 'b' || s[charpos] == 'g' || s[charpos] == 'h' || s[charpos] == 'k' || s[charpos] == 'm' || s[charpos] == 'n' || s[charpos] == 'p' || s[charpos] == 'r') )
        {state = "Qcon1";}
      else if(state == "Q0" && (s[charpos] == 'a' || s[charpos] == 'i' || s[charpos] == 'u' || s[charpos] == 'e' || s[charpos] == 'o' || s[charpos] == 'I' || s[charpos] == 'E'))
        { state = "Q0'";}
      else if(state == "Q0" && (s[charpos] == 'd' || s[charpos] == 'j' || s[charpos] == 'w' || s[charpos] == 'y' || s[charpos] == 'z'))
        { state = "Qcon";}
      else if(state == "Q0" && s[charpos] == 's')
        { state = "QS";}
	  else if(state == "Q0" && s[charpos] == 't')
		{ state = "QT";}
	  else if(state == "Q0" && s[charpos] == 'c')
	    { state = "QC";}
	  else
	     { // Qcon1                                                                                                                                                                                      
		  if (state == "Qcon1" && (s[charpos] == 'a' || s[charpos] == 'i' || s[charpos] == 'u' || s[charpos] == 'e' || s[charpos] == 'o' || s[charpos] == 'I' || s[charpos] == 'E'))
		  {state = "Q0'";}
		  else if(state == "Qcon1" && s[charpos] == 'y')
		  { state = "Qcon";}
		  else
		    { // Q0'                                                                                                                                                                                          
              if(state == "Q0'" && s[charpos] == 'n')
				{ state = "Q0"; }
     		  else if (state == "Q0'" && (s[charpos] == 'b' || s[charpos] == 'g' || s[charpos] == 'h' || s[charpos] == 'k' || s[charpos] == 'm' || s[charpos] == 'n' || s[charpos] == 'p' || s[charpos] == 'r') )
				{state = "Qcon";}
		      else if(state == "Q0'" && (s[charpos] == 'a' || s[charpos] == 'i' || s[charpos] == 'u' || s[charpos] == 'e' || s[charpos] == 'o' || s[charpos] == 'I' || s[charpos] == 'E'))
				{ state = "Q0'";}
		      else if(state == "Q0'" && (s[charpos] == 'd' || s[charpos] == 'j' || s[charpos] == 'w' || s[charpos] == 'y' || s[charpos] == 'z'))
				{ state = "Qcon";}
		      else if(state == "Q0'" && s[charpos] == 's')
				{ state = "QS";}
			  else if(state == "Q0'" && s[charpos] == 't')
				{ state = "QT";}
			  else if(state == "Q0'" && s[charpos] == 'c')
			    { state = "QC";}
			  else
				{ // Qcon                                                                                                                                                                          
				  if(state == "Qcon" && (s[charpos] == 'a' || s[charpos] == 'i' || s[charpos] == 'u' || s[charpos] == 'e' || s[charpos] == 'o' || s[charpos] == 'I' || s[charpos] == 'E'))
				    { state = "Q0'";}
				  else
				    { // QS                                                                                                                                                                           
				      if(state == "QS" && (s[charpos] == 'a' || s[charpos] == 'i' || s[charpos] == 'u' || s[charpos] == 'e' || s[charpos] == 'o' || s[charpos] == 'I' || s[charpos] == 'E'))
					  { state = "Q0'";}
				      else if(state == "QS" && s[charpos] == 'h')
					  { state = "Qcon";}
					  else
					  { //QT                                                                                                                                                                       
					    if(state == "QT" && (s[charpos] == 'a' || s[charpos] == 'i' || s[charpos] == 'u' || s[charpos] == 'e' || s[charpos] == 'o' || s[charpos] == 'I' || s[charpos] == 'E'))
					      { state = "Q0'";}
					    else if(state == "QT" && s[charpos] == 's')
					      { state = "Qcon";}
					    else
						  { //QC                                                                                                                                                                  
							if(state == "QC" && s[charpos] == 'h')
						      { state = "Qcon";}
						    else
						      { 
							return false;}
						  }
					  }
				  }
			    }
		    }
	     }
      
      charpos++;
      
    }//end of while                                                                                                                                                                                           
  
  // final location ...                                                                                                                                                                                   
  if (state == "Q0" || state == "Q0'") 
    {
      return true;
    }
  return false;
}


//PERIOD DFA here 
//Done by: ** Ahmad Dehani 
bool period(string s)
{
  int state = 0;
  int charpos = 0;
  
  //testing if it is a period "."
  while (s[charpos] != '\0')
    {
      if (state == 0 && s[charpos] == '.')
	state = 1;
      else
	return(false);
      
      ++charpos;
    }
  
  if (state == 1) return(true);
  else return(false);
}
// ------ Three  Tables -------------------------------------

// TABLES Done by: ** Kevin Winstead

// ** Update the tokentype to be WORD1, WORD2, PERIOD, ERROR, EOFM, etc.                                                                                                              
enum tokentype { WORD1, WORD2, PERIOD, ERROR, VERB, VERBNEG, VERBPAST, VERBPASTNEG, IS, WAS, OBJECT, SUBJECT, DESTINATION, PRONOUN, CONNECTOR };
// ** For the display names of tokens - must be in the same order as the tokentype.          
string tokenName[30] = { "WORD1", "WORD2", "PERIOD", "ERROR", "VERB", "VERBNEG","VERBPAST","VERBPASTNEG","IS","WAS", "OBJECT", "SUBJECT","DESTINATION", "PRONOUN", "CONNECTOR" };
// ** Need the reservedwords table to be set up here.
// ** Do not require any file input for this. Hard code the table.
// ** a.out should work without any additional files.
// tables                                                                                                                       
struct reserved
{
  const char* string;
  tokentype thetype;
}
  reserved[] = {
    {"masu",VERB},
    {"masen",VERBNEG},
    {"mashita",VERBPAST},
    {"masendeshita",VERBPASTNEG},
    {"desu",IS},
    {"deshita",WAS},
    {"o", OBJECT},
    {"wa", SUBJECT},
    {"ni", DESTINATION},
    {"watashi",PRONOUN},
    {"anata",PRONOUN},
    {"kare",PRONOUN},
    {"kanojo", PRONOUN},
    {"sore", PRONOUN},
    {"mata",CONNECTOR},
    {"soshite", CONNECTOR},
    {"shikashi", CONNECTOR},
    {"dakara", CONNECTOR}};

// ------------ Scaner and Driver ----------------------- 

ifstream fin;  // global stream for reading from the input file

// Scanner processes only one word each time it is called
// Gives back the token type and the word itself
// ** Done by: Ahmad Dehaini and Kevin Winstead 
int scanner(tokentype& tt, string& w)
{
  // ** Grab the next word from the file via fin
  // 1. If it is eofm, return right now.
    /*  **
      2. Call the token functions (word and period)
      one after another (if-then-else).
      Generate a lexical error message if both DFAs failed.
      Let the tokentype be ERROR in that case.
      
      3. If it was a word,
      check against the reservedwords list.
      If not reserved, tokentype is WORD1 or WORD2
      decided based on the last character.
      
      4. Return the token type & string  (pass by reference)
  */
  // ** Grab the next word from the file via fin
  
  //step 2
  
  fin >> w;
  if(word(w)) //checking step 2, part 1
    {
      for (int i = 0; i < 18; i++)
	{
	  if (w == reserved[i].string) //checking step 3, part 1
	    {
	      tt = reserved[i].thetype;
	      return 0;
	    }
	}
      
      char lastLetter = ' ';
      lastLetter = w[(w.length()-1)];
      
      //checking step 3, part 2
      if (lastLetter == 'I' || lastLetter == 'E')
	{
	  tt = WORD2;
	}
      else
	{
	  tt = WORD1;
	}      
      
    }
  else if(period(w)) //checking step 2, part 2
    {
      tt = PERIOD;
    }
  else if(w == "eofm")
    {}
  else
    {
      cout << "LEXICAL ERROR: "<< w <<" is not a valid token \n";
      tt = ERROR;
    }
  return 0;
}//the end of scanner



// The temporary test driver to just call the scanner repeatedly  
// This will go away after this assignment
// DO NOT CHANGE THIS!!!!!! 
// Done by:  Rika
/*
int main()
{
  tokentype thetype;
  string theword;
  string filename;
  
  cout << "Enter the input file name: ";
  cin >> filename;

  fin.open(filename.c_str());

  // the loop continues until eofm is returned.
  while (true)
    {
      scanner(thetype, theword);  // call the scanner which sets
      // the arguments
      if (theword == "eofm") break;  // stop now

      cout << "Type is:" << tokenName[thetype] << endl;
      cout << "Word is:" << theword << endl << endl;
    }

  cout << "End of file" << endl;
  fin.close();

}// end
*/
