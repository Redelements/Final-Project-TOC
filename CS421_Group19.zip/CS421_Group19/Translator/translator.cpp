#include<iostream>
#include<fstream>
#include<string>
#include"scanner.cpp"
#include<vector>
#include<stdlib.h>
using namespace std;

/* INSTRUCTION:  copy your parser.cpp here
      cp ../ParserFiles/parser.cpp .
   Then, insert or append its contents into this file and edit.
   Complete all ** parts.
*/

//=================================================
// File translator.cpp written by Group Number: **19
//=================================================

// ----- Additions to the parser.cpp ---------------------

// ** Declare Lexicon (i.e. dictionary) that will hold the content of lexicon.txt
// Make sure it is easy and fast to look up the translation.
// Do not change the format or content of lexicon.txt 
//  Done by: ** Joel Antony 


// ** Additions to parser.cpp here:
//    getEword() - using the current saved_lexeme, look up the English word
//                 in Lexicon if it is there -- save the result   
//                 in saved_E_word
//  Done by: ** Kevin WInstead
//    gen(line_type) - using the line type,
//                     sends a line of an IR to translated.txt
//                     (saved_E_word or saved_token is used)
//  Done by: ** Ahmad Dehaini 

// ----- Changes to the parser.cpp content ---------------------

// ** Comment update: Be sure to put the corresponding grammar 
//    rule with semantic routine calls
//    above each non-terminal function 

// ** Each non-terminal function should be calling
//    getEword and/or gen now.
// ==================================================================

void verb();
void be();
void tense();
void s();
void afterSubject();
void afterNoun();
void afterObject();
void noun();


ofstream outfile;

string saved_lexeme;
bool  token_available = false;
tokentype saved_token;

string savedEword;

//Table for translation
//Done By: Kevin Winstead
vector<string> wordJ ;
vector <string> wordE ;



//Done By: Ahmad Dehaini
//Function getEword: takes the current saved lexeme and checks it aganst the translation table
void getEword()
{
  bool found = false;
  for(int i =0;i< wordJ.size(); i++)
    {
      if(wordJ[i]==saved_lexeme)
	{savedEword = wordE[i];
	  found = true;
	}
    }
  if(found == false)
    savedEword = saved_lexeme;
}


//Done By: Ahmad Dehaini
//Function gen: generates a file output based on our saved line and our token or savedEword
void gen(string line_type)
{
  if(line_type == "TENSE")
    {outfile << line_type<< "  "<< tokenName[saved_token] <<endl;}
  else{
    outfile << line_type<< "  "<< savedEword <<endl;
  }
}
//=================================================
// File parser.cpp written by Group Number: ** 19
//=================================================


// ----- Four Utility Functions and Globals -----------------------------------
// ** Need syntaxerror1 and syntaxerror2 functions (each takes 2 args)
//    to display syntax error messages as specified by me.  

// Type of error: ** Syntex 
// Done by: ** Kevin Winstead 
void syntax_error1(tokentype expected, string saved_lexeme)
{
  cout << "SYNTAX ERROR: expected "<< tokenName[expected]  << " but found "<<  saved_lexeme <<endl;
  exit(1); 
}
// Type of error: ** 
// Done by: ** kevin Winstead
void syntax_error2(string saved_lexeme, string parserFunct) 
{
  cout << "sysntax error unexprected " << saved_lexeme << "found in " << parserFunct << endl;
  exit(1);
}

// ** Need the updated match and next_token with 2 global vars
// saved_token and saved_lexeme

// Purpose: **
// Done by: **Joel and Ahmad
tokentype next_token()
{
  if (!token_available)                                                     
    {
      scanner(saved_token, saved_lexeme);  // call scanner to grab a new token              
      cout<<"Scanner called using word: "<< saved_lexeme <<endl;
      token_available = true;                              // mark that fact that you have aved it          
    }
  return saved_token;    // return the saved token                                                           
}


// Purpose: **
// Done by: **  Ahmad Dehani
bool match(tokentype expected) 
{
  if (next_token() != expected)  // mismatch has occurred with the next token
    {
      syntax_error1(expected, saved_lexeme);// calls a syntax error function here to  generate a syntax error message here and do recovery
     
    }
  else  // match has occurred
    { 
      cout<<"Matched "<< tokenName[expected] <<endl; //print the matched token type, when successful
      token_available = false;  // eat up the token
      return true;              // say there was a match
    }
}

// ----- RDP functions - one per non-term -------------------

// ** Make each non-terminal into a function here
// ** Be sure to put the corresponding grammar rule above each function
// ** Be sure to put the name of the programmer above each function
 
//Grammar:<story> ::= <s>{<s>}
//Done By: Kevin WInstead

void story()
{
  cout<<"Processing <story>"<<endl;
  s();
  //while()  call more s()
  while (true && (saved_lexeme != "eofm"))  
    {
      outfile<<endl;
      s();
    }
  cout<<"\nSuccessfully parsed story"<<endl;
}

//Grammar:<s> ::= [CONNECTOR]<noun>SUBJECT<after subject>                       
//Done By:  Ahmad Dehani
void s()
{
  next_token();
  if(saved_lexeme != "eofm")
    {

      cout<<"Processing <s>"<<endl;

  
      if(next_token() == CONNECTOR)
	{
	  match(CONNECTOR);
	  getEword();
	  gen("CONNECTOR");
	}
  
      noun();
      match(SUBJECT);
      gen("ACTOR");
      afterSubject();
  
    }
}

//Grammar:<noun> ::= WORD1|PRONOUN
//Done By: Ahmad Dehani
void noun()
{
  cout<<"Processing <noun>"<<endl;
  switch(next_token())  // look ahead at next token                                                                        
    {
    case  WORD1:
      match(WORD1);
      getEword();
      break;
    case  PRONOUN:
      match(PRONOUN);
      getEword();
      break;
    default:
      syntax_error2(saved_lexeme, "noun");  // none of the alternatives found                                                                                                                            
    }
}

//Grammar: <after subject> ::= <verb> <tense> PERIOD | <noun> <after noun>   
//Done By: Joel Antony
void afterSubject()
{
  cout<<"Processing <afterSubject>"<<endl;
  
  switch(next_token())  // look ahead at next token                                          
    {
    case  WORD2:
      verb();
      tense();
      match(PERIOD);
      break;
    case  WORD1:
      noun();
      afterNoun();
      break;
    case PRONOUN:
      noun();
      afterNoun();
      break;
    default:
      syntax_error2(saved_lexeme, "afterSubject");  // none of the alternatives found    
    }
}


//Grammar: <verb> ::= WORD2
//Done By: Kevin Winstead
void verb()
{
  cout<<"Processing <verb>"<<endl;

  switch(next_token())  // look ahead at next token                                                                                                             
    {
    case  WORD2:
      match(WORD2);
      getEword();
      gen("ACTION");
      break;
    default:
      syntax_error2(saved_lexeme, "verb");  // none of the alternatives found                         
    }
}

//Grammar: <be> ::= IS | WAS
//Done By: Joel Antony
void be()
{
  cout<<"Processing <be>"<<endl;
  gen("DESCRIPTION");
  switch(next_token())  // look ahead at next token                                         
    {
    case  IS:
      match(IS);
      gen("TENSE");
      break;
    case  WAS:
      match(WAS);
      gen("TENSE");
      break;
    default:
      syntax_error2(saved_lexeme, "be");  // none of the alternatives found                
    }
}



//Grammar:<after noun> ::= <be> PERIOD  | DESTINATION <verb> <tense> PERIOD | OBJECT  <after object>
//Done By: Kevin Winstead and Joel Antony
void afterNoun()
{
  cout<<"Processing <afterNoun>"<<endl;

  
  switch(next_token())  // look ahead at next token       
    {
    case  IS:
      be();
      match(PERIOD);
      break;
    case  WAS:
      be();
      match(PERIOD);
      break;
    case DESTINATION:
      match(DESTINATION);
      gen("TENSE");
      verb();
      tense();
      match(PERIOD);
      break;
    case OBJECT:
      match(OBJECT);
      gen("OBJECT");
      afterObject();
      break;
    default:
      syntax_error2(saved_lexeme, "afterNoun");  // none of the alternatives found                
    }
  
}

//Grammar:<after object> ::= <verb><tense> PERIOD | <noun>DESTINATION <verb> <tense> PERIOD
//Done By:  Joel Antony 
void afterObject()
{
  cout<<"Processing <afterObject>"<<endl;
  
  switch(next_token())
    {
    case WORD2:
      verb();
      tense();
      match(PERIOD);
      break;
    case WORD1:
      noun();
      match(DESTINATION);
      gen("TO");
      verb();
      tense();
      match(PERIOD);
      break;
    case PRONOUN:
      noun();
      match(DESTINATION);
      gen("TO");
      verb();
      tense();
      match(PERIOD);
      break;
    default:
      syntax_error2(saved_lexeme, "afterObject");  // none of the alternatives found    
    }
}


//Grammar: <tense> ::= VERBPAST | VERBPASTNEG | VERB | VERBNEG
//Done By: Ahmad Dehani
void tense()
{
  cout<<"Processing <tense>"<<endl;

  switch(next_token())  // look ahead at next token                                                                    
    {
    case  VERBPAST:
      match(VERBPAST);
      gen("TENSE");
      break;
    case  VERBPASTNEG:
      match(VERBPASTNEG);
      gen("TENSE");
      break;
    case  VERB:
      match(VERB);
      gen("TENSE");
      break;
    case  VERBNEG:
      match(VERBNEG);
      gen("TENSE");
      break;
    default:
      syntax_error2(saved_lexeme, "tense");  // none of the alternatives found                                                              
    }
}

// ---------------- Driver ---------------------------

// The final test driver to start the translator
// Done by:  ** Kevin Winstead
int main()
{
  //** opens the lexicon.txt file and reads it into Lexicon
  //** closes lexicon.txt 
  ifstream in;
  string ram;
  string bo;
  string filename;
  in.open("lexicon.txt");
  cout << "Openning Lexicon.txt" << endl;
  while(in)
    {
      
      in>> ram;
      in>> bo;
      wordJ.push_back(ram);
      wordE.push_back(bo);
    }
  //** closes the input file
  in.close();
  //** closes traslated.txt
  //** opens the output file translated.txt
  //** calls the <story> to start parsing

  outfile.open("translated.txt");
  cout << "Enter the input file name: ";
  cin >> filename;
  fin.open(filename.c_str());
  story();
  fin.close();
  outfile.close();
}// end
//** require no other input files!
//** syntax error EC requires producing errors.txt of error messages
//** tracing On/Off EC requires sending a flag to trace message output functions

